import Navbar from "./components/Navbar"
import FooterComponent from "./components/Footer";
import Designstudio from "./components/Sheets";

export default function Home() {
  return (
    <>
      <Navbar />
      <Designstudio/>
      <FooterComponent />
    </>
  );
}
